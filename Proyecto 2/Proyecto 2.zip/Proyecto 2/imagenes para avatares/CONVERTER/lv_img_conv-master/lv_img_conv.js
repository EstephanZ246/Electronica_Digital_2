#!/usr/bin/perl -e$_=$ARGV[0];exec("/usr/bin/env\x20npx\x20ts-node\x20-s\x20@ARGV")
require('./lib/cli.ts');
