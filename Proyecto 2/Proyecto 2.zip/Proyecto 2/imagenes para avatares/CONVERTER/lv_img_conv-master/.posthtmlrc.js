module.exports = {
  plugins: {
    'posthtml-include': {
      root: './web'
    }
  }
};
