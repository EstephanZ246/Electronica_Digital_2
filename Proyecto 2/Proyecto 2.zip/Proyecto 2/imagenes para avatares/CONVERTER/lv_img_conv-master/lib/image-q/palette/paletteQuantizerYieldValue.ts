import { Palette } from '../utils';

export interface PaletteQuantizerYieldValue {
  progress: number;
  palette?: Palette;
}
