Youtube: https://youtu.be/0skPAuBrCAY
Github: https://github.com/EstephanZ246/Electronica_Digital_2